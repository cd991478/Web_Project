package Hospital.Patient.Entity;

import org.springframework.data.jpa.repository.JpaRepository;

public interface D_HospitalRepository extends JpaRepository<D_Hospital, Integer> {

}
